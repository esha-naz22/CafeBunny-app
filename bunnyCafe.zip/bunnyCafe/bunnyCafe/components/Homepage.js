import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  FlatList,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  ImageBackground,
  Image,
  StyleSheet,
} from 'react-native';
import { Picker } from '@react-native-picker/picker';

import FontAwesome from 'react-native-vector-icons/FontAwesome';

const coverimg = require('../assets/images/copi(12).png');

function List({ category, searchQuery, onItemPress }) {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function fetchProducts() {
      try {
        const response = await fetch('https://my-new-app-e91bc-default-rtdb.firebaseio.com/Products.json');
        if (!response.ok) throw new Error('Network error');

        const data = await response.json();
        const productsArray = [];

        for (const key in data) {
          const product = data[key];

          if (product && (!category || product.category === category)) {
            productsArray.push({
              id: key,
              name: product.name || 'Unnamed',
              price: product.price || '0',
              description: product.description || 'No description',
              category: product.category || '',
              image: product.image || null,  // Added image field here
            });
          }
        }

        setProducts(productsArray);
      } catch (err) {
        setError(err);
      } finally {
        setLoading(false);
      }
    }

    fetchProducts();
  }, [category]);

  const filtered = products.filter(p =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) return <ActivityIndicator style={{ marginTop: 20 }} />;
  if (error) return <Text>Error loading: {error.message}</Text>;
  if (!filtered.length) return <Text style={{ marginTop: 20 }}>No products found.</Text>;

  return (
    <FlatList
      data={filtered}
      numColumns={2}
      keyExtractor={item => item.id}
      columnWrapperStyle={{ justifyContent: 'space-between' }}
      renderItem={({ item }) => (
        <TouchableOpacity onPress={() => onItemPress(item)} style={styles.card}>
          {item.image ? (
            <Image
              source={{ uri: item.image }}
              style={styles.productImage}
              resizeMode="cover"
            />
          ) : (
            <View style={styles.imagePlaceholder}>
              <Text style={{ color: '#aaa' }}>No Image</Text>
            </View>
          )}

          <Text style={styles.productName}>{item.name}</Text>
          <Text style={styles.productPrice}>Rs {item.price}</Text>
          {/* <Text style={styles.productDesc} numberOfLines={2}>
            {item.description}
          </Text> */}

          <TouchableOpacity style={styles.addToCartBtn}>
            <Text style={styles.addToCartText}>Add to Cart</Text>
          </TouchableOpacity>
        </TouchableOpacity>
      )}
    />
  );
}

export default function Homepage({ navigation }) {
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [menuVisible, setMenuVisible] = useState(false);

  return (
    <ScrollView contentContainerStyle={{ padding: 10 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'flex-end', padding: 10, zIndex: 999, marginTop: 25 }}>
        <TouchableOpacity onPress={() => setMenuVisible(!menuVisible)}>
          <FontAwesome name="bars" size={24} color="black" />
        </TouchableOpacity>

        {menuVisible && (
          <View style={styles.dropdown}>
            <TouchableOpacity
              onPress={() => navigation.navigate('NewProduct')}
              style={{ marginTop: 20, padding: 10, backgroundColor: 'white', alignSelf: 'center' }}
            >
              <Text> Add New Product</Text>
            </TouchableOpacity>

           <TouchableOpacity
              onPress={() => navigation.navigate('ProductList')}
              style={{  padding: 10, backgroundColor: 'white', alignSelf: 'center',  }}
            >
              <Text> Product lists</Text>
            </TouchableOpacity>



          </View>
        )}
      </View>

      <Text style={styles.herone}>Caffeine Coffee Shop</Text>
      <Text style={styles.herotwo}>Coffee at first</Text>

      <View style={{ flexDirection: 'row', backgroundColor: 'white', margin: 10, borderRadius: 20, borderWidth: 1, borderColor: "black" }}>
        <TextInput
          style={styles.input}
          placeholder="Search coffee..."
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
        <FontAwesome name="search" size={20} style={styles.magni} />
      </View>

      <ImageBackground source={coverimg} style={styles.bgim}>
        <View style={styles.overlay} />

        <View style={styles.textContainer}>
          <Text style={styles.title}>"Discover Your Next Favorite"</Text>
          <Text style={styles.subtitle}>Explore our wide range of handcrafted beverages  made with love!</Text>
        </View>
      </ImageBackground>

      <Text style={{ fontSize: 18, marginVertical: 10 }}>Select Category:</Text>
      <FontAwesome name="sliders" size={20} style={styles.filterIcon} />

      <View style={styles.btning}>
        {['All', 'Latte', 'Mocha', 'Cappuccino', 'Espresso'].map(cat => {
          const isSelected = selectedCategory === cat || (cat === 'All' && selectedCategory === null);
          return (
            <TouchableOpacity
              key={cat}
              style={[styles.catebtn, isSelected && styles.selectedBtn]}
              onPress={() => setSelectedCategory(cat === 'All' ? null : cat)}
            >
              <Text style={[styles.cattext, isSelected && styles.selectedText]}>
                {cat}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>

      <View style={{ marginTop: 20 }}>
        <List
          category={selectedCategory}
          searchQuery={searchQuery}
          onItemPress={item => navigation.navigate('Details', { product: item })}
        />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  herone: {
    marginTop: -38,
    marginLeft: 10,
    fontSize: 24,
    fontWeight: "bold",
    fontFamily: "Onpen Sans"
  },

  herotwo: {
    marginLeft: 10,
    fontSize: 13,
    fontFamily: "lato"
  },

  input: {
    flex: 1,
    paddingHorizontal: 10,
    zIndex: -2,
  },

  magni: {
    padding: 10,
    backgroundColor: "#734128",
    borderTopRightRadius: 25,
    borderBottomRightRadius: 25,
    color: "white"
  },

  bgim: {
    width: '100%',
    height: 150,
    justifyContent: 'center',
    borderRadius: 24,
  },

  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.7)',
  },

  textContainer: {
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  title: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
  },
  subtitle: {
    color: '#fff',
    fontSize: 12,
    marginTop: 10,
    textAlign: "center",
  },
  filterIcon: {
    textAlign: "right",
    position: "relative",
    marginTop: -30,
    marginRight: 10,
  },
  btning: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 20,
  },

  catebtn: {
    borderWidth: 1,
    borderColor: '#734128',
    borderRadius: 25,
    paddingVertical: 4,
    paddingHorizontal: 10,
    marginRight: 10,
    backgroundColor: '#fff',
  },

  selectedBtn: {
    backgroundColor: '#734128',
    paddingVertical: 5,
    paddingHorizontal: 7,
  },

  cattext: {
    color: '#734128',
    fontSize: 16,
    fontWeight: '500',
    fontFamily: "poppins",
  },

  selectedText: {
    color: 'white',
  },

  card: {
    width: '48%',
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 10,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#ddd',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },

  imagePlaceholder: {
    height: 100,
    borderRadius: 8,
    backgroundColor: '#f2f2f2',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
  },

  productImage: {
    width: '100%',
    height: 100,
    borderRadius: 8,
    marginBottom: 10,
  },

  productName: {
    fontWeight: 'bold',
    fontSize: 16,
    textAlign: "center",
    marginBottom: 4,
    color: '#333',
  },

  productPrice: {
    color: 'green',
    fontSize: 14,
    marginBottom: 4,
    textAlign: "center"
  },

  productDesc: {
    fontSize: 12,
    color: '#666',
    textAlign: "center",
    marginBottom: 8,
  },

  addToCartBtn: {
    backgroundColor: '#734128',
    borderRadius: 20,
    paddingVertical: 6,
    alignItems: 'center',
  },

  addToCartText: {
    color: 'white',
    fontSize: 14,
    fontFamily: "poppins"
  },

  dropdown: {
    position: 'absolute',
    top: 45,
    right: 10,
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    zIndex: 1000,
    elevation: 5,
  },

  dropdownItem: {
    padding: 10,
  },

  dropdownText: {
    fontSize: 16,
    color: 'black',
  },
});
