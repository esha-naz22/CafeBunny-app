import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  ScrollView,
  Alert,
} from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { getAuth } from 'firebase/auth';
import { getDatabase, ref, push } from 'firebase/database';
import { FontAwesome } from '@expo/vector-icons';
import Payment from './Payment';

export default function TypeDetail({ route, navigation }) {
  const { product } = route.params;
  const [quantity, setQuantity] = useState(1);
  const [selectedSize, setSelectedSize] = useState('Medium');
  const [showPopup, setShowPopup] = useState(false);
  const [showPayment, setShowPayment] = useState(false);

  const totalWithDelivery = product.price * quantity + 200;

  const mapSizeBack = (shortSize) => {
    if (shortSize === 'S') return 'Small';
    if (shortSize === 'M') return 'Medium';
    if (shortSize === 'L') return 'Large';
    return shortSize;
  };

  const handleAddToCart = () => {
    const auth = getAuth();
    const user = auth.currentUser;

    if (!user) {
      Alert.alert('Login Required', 'Please login first to add items to cart.');
      return;
    }

    const db = getDatabase();
    const cartRef = ref(db, `userCarts/${user.uid}`);

    const newCartItem = {
      id: product.id,
      name: product.name,
      price: product.price,
      description: product.description || '',
      size: mapSizeBack(selectedSize),
      quantity: quantity,
    };

    push(cartRef, newCartItem)
      .then(() => {
        setShowPopup(true);
        setTimeout(() => setShowPopup(false), 2000);
      })
      .catch((error) => {
        console.error('Error adding to cart:', error);
        Alert.alert('Error', 'Something went wrong while adding to cart.');
      });
  };

  const handleBuyNow = () => {
    const auth = getAuth();
    const user = auth.currentUser;

    if (!user) {
      Alert.alert('Login Required', 'Please login first to place an order.');
      return;
    }

    const db = getDatabase();
    const orderRef = ref(db, `orderHistory/${user.uid}`);

    const now = new Date();
    const date = now.toLocaleDateString();
    const time = now.toLocaleTimeString();

    const newOrder = {
      id: product.id,
      name: product.name,
      price: product.price,
      description: product.description || '',
      size: selectedSize,
      quantity: quantity,
      date,
      time,
    };

    push(orderRef, newOrder)
      .then(() => {
        setShowPayment(true);
      })
      .catch((error) => {
        console.error('Error placing order:', error);
        Alert.alert('Error', 'Failed to place order.');
      });
  };

  return (
    <View style={{ flex: 1 }}>
      <ScrollView style={styles.container}>
        <View style={styles.board}>
          <View style={styles.header}>
            <TouchableOpacity onPress={() => navigation.navigate('Homepage')}>
              <FontAwesome name="arrow-left" size={15} style={styles.backicon} />
            </TouchableOpacity>

           <Image source={require('../assets/images/copi (2).png')}   style={styles.darmyani}
 />
          </View>

          {/* Show All Product Images */}
          <View style={{ alignItems: 'center', marginTop: 60 }}>
            {(product.images ?? []).map((img, index) => (
              <Image
                key={index}
                source={typeof img === 'string' ? { uri: img } : img}
                style={styles.cmonimg}
              />
            ))}
          </View>
        </View>

        <Text style={styles.name}>
          <Text style={{ fontWeight: 'bold' }}></Text> {product.name}
        </Text>
        <Text style={styles.price}>
          <Text style={{ fontWeight: 'bold' }}>PKR </Text> {product.price}
        </Text>
        <Text style={styles.description}>
          <Text style={{ fontWeight: 'bold' }}></Text> {product.description}
        </Text>

        <Text style={styles.sectionTitle}>Size</Text>
        <View style={styles.sizeContainer}>
          {['Small', 'Medium', 'Large'].map((size) => (
            <TouchableOpacity
              key={size}
              style={[
                styles.sizeButton,
                selectedSize === size && styles.sizeButtonSelected,
              ]}
              onPress={() => setSelectedSize(size)}
            >
              <Text
                style={
                  selectedSize === size ? styles.sizeTextSelected : styles.sizeText
                }
              >
                {size}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <Text style={styles.sectionTitle}>Quantity</Text>
        <View style={styles.quantityContainer}>
          <TouchableOpacity
            onPress={() => setQuantity(quantity > 1 ? quantity - 1 : 1)}
            style={styles.qtyButton}
          >
            <Text style={styles.qtyButtonText}>-</Text>
          </TouchableOpacity>

          <Text style={styles.quantityText}>{quantity}</Text>

          <TouchableOpacity
            onPress={() => setQuantity(quantity + 1)}
            style={styles.qtyButton}
          >
            <Text style={styles.qtyButtonText}>+</Text>
          </TouchableOpacity>
        </View>

        <View
          style={{
            display: 'flex',
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
            margin: 10,
          }}
        >
          <TouchableOpacity style={styles.addToCartButton} onPress={handleAddToCart}>
            <Text style={styles.addToCartText}>Add to Cart</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.buyNowButton} onPress={handleBuyNow}>
            <Text style={styles.buyNowText}>Buy Now</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      {showPopup && (
        <View style={styles.popupOverlay}>
          <View style={styles.popupBox}>
            <FontAwesome name="shopping-cart" size={40} color="brown" />
            <Text style={styles.popupTitle}>Awesome</Text>
            <Text style={styles.popupMessage}>
              Your selection has been added to your cart
            </Text>
          </View>
        </View>
      )}

      <Payment
        isVisible={showPayment}
        onClose={() => setShowPayment(false)}
        navigation={{ navigate: (screen, params) => navigation.navigate(screen, params) }}
        totalPrice={totalWithDelivery}
        selectedItems={[
          {
            name: product.name,
            price: product.price,
            quantity: quantity,
            size: selectedSize,
          },
        ]}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff',
  },
  name: {
    fontSize: 26,
    fontWeight: 'bold',
    color: 'black',
    textTransform: 'capitalize',
    marginBottom: 5,
    textAlign: 'center',
  },
  price: {
    fontSize: 20,
    color: 'black',
    textAlign: 'center',
    marginBottom: 10,
  },
  description: {
    fontSize: 16,
    color: 'black',
    textAlign: 'center',
    marginBottom: 20,
  },
  sectionTitle: {
    marginTop: 10,
    fontSize: 18,
    marginLeft: 20,
    fontWeight: 'bold',
    padding: 10,
  },
  sizeContainer: {
    flexDirection: 'row',
    justifyContent: 'space-evenly',
  },
  sizeButton: {
    paddingVertical: 8,
    paddingHorizontal: 18,
    backgroundColor: '#eee',
    borderRadius: 20,
  },
  sizeButtonSelected: {
    backgroundColor: '#734128',
  },
  sizeText: {
    fontSize: 16,
    color: 'black',
  },
  sizeTextSelected: {
    fontSize: 16,
    color: 'white',
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
    darmyani:{
    width: 200,
    height: 200,
    borderRadius: 100,
    position: "absolute",
    justifyContent: "center",
    alignItems: "center",
    top: 30,
    left: 70,
   

  },

  qtyButton: {
    borderRadius: 50,
    marginHorizontal: 10,
  },
  qtyButtonText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'black',
  },
  quantityText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  addToCartButton: {
    backgroundColor: '#734128',
    padding: 10,
    width: '35%',
    alignSelf: 'center',
    borderRadius: 24,
    alignItems: 'center',
    marginBottom: 15,
  },
  addToCartText: {
    color: 'white',
    fontSize: 15,
    fontWeight: 'bold',
    fontFamily: 'Poppins',
  },
  buyNowButton: {
    backgroundColor: '#ebe6de',
    padding: 10,
    width: '35%',
    alignSelf: 'center',
    borderRadius: 24,
    alignItems: 'center',
    marginBottom: 15,
  },
  buyNowText: {
    color: 'black',
    fontSize: 15,
    fontWeight: 'bold',
    fontFamily: 'Poppins',
  },
  popupOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 999,
  },
  popupBox: {
    width: 280,
    backgroundColor: '#fff',
    borderRadius: 15,
    padding: 20,
    alignItems: 'center',
    elevation: 10,
  },
  popupTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    marginTop: 10,
    color: '#000',
  },
  popupMessage: {
    fontSize: 14,
    color: '#333',
    textAlign: 'center',
    marginTop: 5,
  },
  board: {
    width: '100%',
    height: 150,
    position: 'relative',
    backgroundColor: '#734128',
    marginBottom: 100,
    borderBottomRightRadius: 24,
    borderBottomLeftRadius: 24,
  },
  cmonimg: {
    width: 200,
    height: 200,
    borderRadius: 100,
    marginBottom: 10,
  },
  header: {
    marginTop: 30,
    marginLeft: 30,
    padding: 7,
    width: 30,
  },
  backicon: {
    color: 'white',
    fontWeight: 'bold',
  },
});
