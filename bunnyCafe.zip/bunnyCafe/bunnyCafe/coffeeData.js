const coffeeData = [
  { 
    id: 1,
     image: require('./assets/images/beans1.jpg')
     },

  { id: 2, image: require('./assets/images/beans1.jpg') },

];

export default coffeeData;
